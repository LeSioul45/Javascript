window.addEventListener('load', function(event) {
    var monLien = document.getElementById('lien1');
    lien1.addEventListener('click', function(event) {
        document.body.style.backgroundColor = "#cccccc";
        event.preventDefault();
    });
});