function disBonjour(titre, nom) {
    console.debug("Bonjour " + titre + ", " + nom + "!");
}
disBonjour("Monsieur", "toto");
disBonjour("Madame", "tata");
